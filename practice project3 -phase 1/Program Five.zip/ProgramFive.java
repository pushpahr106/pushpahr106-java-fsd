package com.pack;
class Node1 {
    int data;
    Node1 next;

    Node1(int data) {
        this.data = data;
        this.next = null;
    }
}

class SinglyLinkedList {
    private Node1 head;

    SinglyLinkedList() {
        head = null;
    }

    void insert(int newData) {
        Node1 newNode = new Node1(newData);
        if (head == null) {
            head = newNode;
        } else {
            newNode.next = head;
            head = newNode;
        }
    }

    void delete(int key) {
        if (head == null) {
            System.out.println("Linked list is empty. Cannot delete.");
            return;
        }

        if (head.data == key) {
            head = head.next;
            return;
        }

        Node1 current = head;
        while (current.next != null && current.next.data != key) {
            current = current.next;
        }

        if (current.next == null) {
            System.out.println("Key not found in the linked list.");
        } else {
            current.next = current.next.next;
        }
    }

    void display() {
        if (head == null) {
            System.out.println("Linked list is empty.");
            return;
        }

        Node1 current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }
}

public class ProgramFive {
    public static void main(String[] args) {
        SinglyLinkedList list = new SinglyLinkedList();

        list.insert(5);
        list.insert(2);
        list.insert(8);
        list.insert(1);

        System.out.println("Original Linked List:");
        list.display();

        int keyToDelete = 8;
        list.delete(keyToDelete);

        System.out.println("Linked List after deleting " + keyToDelete + ":");
        list.display();
    }
}
