package com.pack;

import java.util.Stack;

public class ProgramEight {
    public static void main(String[] args) {
        // Create a stack
        Stack<Integer> stack = new Stack<>();

        // Push elements onto the stack
        stack.push(1);
        stack.push(2);
        stack.push(3);
        stack.push(4);

        System.out.println("Stack elements after pushing:");
        System.out.println(stack);

        // Pop an element from the stack
        int poppedElement = stack.pop();
        int poppedElement2 = stack.pop();
        System.out.println("Popped Element: " + poppedElement);
        System.out.println("Popped Element: " + poppedElement2);
        System.out.println("Stack elements after popping:");
        System.out.println(stack);
    }
}