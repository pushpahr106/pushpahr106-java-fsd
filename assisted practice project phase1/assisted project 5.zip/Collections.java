package assistedPractice;
import java.util.*;
public class Collections {
	public static void main(String[] args) {

			//creating an Arraylist
			System.out.println("ArrayList");
			ArrayList<String> company=new ArrayList<String>();   
		      company.add("XYZ");
		      company.add("ABC");    	   
		      System.out.println(company);  
		      System.out.println("Vector");
		      Vector<Integer> vect = new Vector();
		      vect.addElement(20); 
		      vect.addElement(45); 
		      System.out.println(vect);
			
			//Creating an Linked list
		      System.out.println("LinkedList");
		      LinkedList<String> empNames=new LinkedList<String>();  
		      empNames.add("vijay");  
		      empNames.add("bharath");  	      
		      Iterator<String> itr=empNames.iterator();  
		      while(itr.hasNext()){  
		       System.out.println(itr.next());  
		       
		       //Creating an Hash set
		       System.out.println("HashSet");
		       HashSet<Integer> set=new HashSet<Integer>();  
		       set.add(111);  
		       set.add(114);  
		       set.add(112);
		       set.add(113);
		       System.out.println(set);
		       
		       //Creating an Linkedhash set
		       System.out.println("LinkedHashSet");
		       LinkedHashSet<Integer> set2=new LinkedHashSet<Integer>();  
		       set2.add(01);  
		       set2.add(02);  
		       set2.add(03);
		       set2.add(04);	       
		       System.out.println(set2);
		      	} 


}
}
