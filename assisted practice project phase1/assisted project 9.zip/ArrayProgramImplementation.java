package assistedPractice;
public class ArrayProgramImplementation {
	public static void main(String[] args) {
		int[]numbers= {1,2,3,4,5};
		System.out.println("Elements of Array");
		for(int i=0;i<numbers.length;i++) {
			System.out.println(numbers[i]);
		}
		int sum=0;
		for(int n : numbers) {
			sum=sum+n;
		}
		System.out.println(sum);
		numbers[3]=6;
		System.out.println(numbers[3]);
	}
}
