package assistedPractice;

import java.io.*;

public class CreatingFile {
    public static void main(String[] args) {
        String filePath = "example.txt";

        // Creating a file
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            writer.write("example content");
            System.out.println("File created and data written.");
        } catch (IOException e) {
            System.err.println("Error creating or writing to the file: " + e.getMessage());
        }

        // Read the data
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            System.out.println("\nReading data from the file:");
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }
        } catch (IOException e) {
            System.err.println("Error reading from the file: " + e.getMessage());
        }

        // Update the file content
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath, true))) {
            writer.newLine(); // Add a newline character
            writer.write("This is additional content.");
            System.out.println("\nFile content updated.");
        } catch (IOException e) {
            System.err.println("Error updating the file: " + e.getMessage());
        }

       
        // Delete the file
        File fileToDelete = new File(filePath);
        if (fileToDelete.delete()) {
            System.out.println("\nFile deleted successfully.");
        } else {
            System.err.println("Error deleting the file.");
        }
    }
}
