package assistedPractice;

public class ThreadProgram extends Thread
{
 	public void run()
 	{
  		System.out.println("Thread program");
}
 	public static void main( String args[] )
 	{
  		ThreadProgram t = new  ThreadProgram();
  		t.start();
 	}
}
