package assistedPractice;
interface InterfaceOne 
{  
    default void show() 
    { 
        System.out.println("welcome to java"); 
    } 
} 
interface Interfacetwo 
{  
    default void show() 
    { 
        System.out.println("welcome to interface"); 
    } 
}  
public class DiamondProgram implements InterfaceOne ,Interfacetwo 
{  
    public void show() 
    {  
    	InterfaceOne .super.show(); 
    	Interfacetwo .super.show(); 
    } 
    public static void main(String args[]) 
    { 
        DiamondProgram ob = new DiamondProgram(); 
        ob.show(); 
    } 
}



