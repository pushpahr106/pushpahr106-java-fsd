package assistedPractice;

//Custom exception class
class CustomException extends Exception {
 public CustomException(String message) {
     super(message);
 }
}

public class CustomExceptionHandling {
 // A method that throws a custom exception
 public static void validateAge(int age) throws CustomException {
     if (age < 18) {
         throw new CustomException("Age must be 18 or older.");
     }
     System.out.println("Age is valid.");
 }

public class ExceptionOne{
 public static void main(String[] args) {
     try {
         int age = 16; // Change the age to test different scenarios
         validateAge(age);
     } catch (CustomException e) {
         System.err.println("Custom Exception: " + e.getMessage());
     } finally {
         System.out.println("Finally block executed.");
     }
 }
}
}